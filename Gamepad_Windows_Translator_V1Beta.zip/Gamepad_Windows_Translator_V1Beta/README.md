# Gamepad Windows Translator V1Beta

Control Fusion 360 (and other software) using a USB gamepad / Xbox-style controller.

* * *

## Features

* Right joystick orbit control by default
* Left joystick normal mouse control by default
* Option to swap left/right joystick roles
* D-pad simple orbit control
* LT / RT zoom control
* X = left click
* B = right click
* Optional cursor catch-up after orbit
* Axis inversion options
* Normal / fast speed toggle with joystick click
* Tabbed interface
* Debug tab with input log

* * *

## Hardware

* USB gamepad / Xbox-style controller
* Windows PC

Tested with a controller exposing these inputs:

* Left joystick: `ABS_X` / `ABS_Y`
* Right joystick: `ABS_RX` / `ABS_RY`
* LT: `ABS_Z`
* RT: `ABS_RZ`

* * *

## Installation (Windows)

1. Install Python 3.12
2. Run:

```bat
INSTALL_DEPENDANCES_V1Beta.bat
```

This installs:

```text
inputs
pyautogui
```

* * *

## Run

```bat
RUN_GAMEPAD_TRANSLATOR_V1Beta.bat
```

* * *

## Default controls

* Right joystick → Fusion orbit mode (Shift + middle mouse + mouse move)
* Left joystick → normal mouse movement
* D-pad → simple orbit mode (middle mouse + mouse move)
* LT / RT → zoom
* X → left click
* B → right click
* Y → manual cursor catch-up if enabled
* Joystick click → toggle speed mode for the assigned role

The checkbox **“Inverser joysticks : droit=orbite / gauche=souris”** is enabled by default.
Disable it if you want:

* Left joystick → Fusion orbit
* Right joystick → normal mouse movement

* * *

## Notes

* This is a beta version.
* The program reads the gamepad with `inputs` and sends mouse/keyboard events with `pyautogui`.
* If the controller is not detected, first check it in Windows with `joy.cpl`.
* Some USB hubs can be unstable with gamepads. Plugging directly into the PC may help.
* Fusion 360 zoom direction can be inverted in the options.

* * *

## License

MIT License

* * *

## Roadmap

* Standalone executable (no Python required)
* Per-software profiles
* Custom button mapping
* Save / load presets
* Cleaner public UI

* * *

## Demo

(see YouTube video)
