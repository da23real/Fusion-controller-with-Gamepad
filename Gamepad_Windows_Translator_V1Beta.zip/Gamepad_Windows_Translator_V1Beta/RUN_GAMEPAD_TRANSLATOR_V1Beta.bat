@echo off
cd /d "%~dp0"
py -3.12 Gamepad_Windows_Translator_V1Beta.py
pause
